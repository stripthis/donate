-- phpMyAdmin SQL Dump
-- version 3.1.2deb1ubuntu0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 12, 2009 at 06:00 PM
-- Server version: 5.0.75
-- PHP Version: 5.2.6-3ubuntu4.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

--
-- Database: `donate`
--

-- --------------------------------------------------------

--
-- Table structure for table `addresses`
--

CREATE TABLE IF NOT EXISTS `addresses` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `contact_id` char(36) collate utf8_unicode_ci NOT NULL,
  `line_1` varchar(150) collate utf8_unicode_ci NOT NULL,
  `line_2` varchar(200) collate utf8_unicode_ci NOT NULL,
  `zip` varchar(20) collate utf8_unicode_ci NOT NULL,
  `country_id` char(36) collate utf8_unicode_ci NOT NULL,
  `state_id` char(36) collate utf8_unicode_ci NOT NULL,
  `city_id` char(36) collate utf8_unicode_ci NOT NULL,
  `contactable` tinyint(1) NOT NULL default '1',
  `primary` tinyint(1) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appeals`
--

CREATE TABLE IF NOT EXISTS `appeals` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `parent_id` char(36) collate utf8_unicode_ci NOT NULL,
  `lang` varchar(3) collate utf8_unicode_ci NOT NULL default 'eng',
  `appeal_step_count` int(2) NOT NULL default '1',
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `slug` varchar(100) collate utf8_unicode_ci NOT NULL,
  `campaign_code` varchar(100) collate utf8_unicode_ci NOT NULL,
  `default` tinyint(1) NOT NULL,
  `cost` decimal(10,2) default NULL,
  `targeted_income` decimal(10,2) unsigned default NULL,
  `targeted_signups` int(10) unsigned default NULL,
  `reviewed` tinyint(1) NOT NULL,
  `status` enum('draft','published','archived') collate utf8_unicode_ci NOT NULL default 'draft',
  `processing` enum('redirect','direct','manual') collate utf8_unicode_ci NOT NULL default 'redirect',
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  `template_id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appeals_themes`
--

CREATE TABLE IF NOT EXISTS `appeals_themes` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `appeal_id` char(36) collate utf8_unicode_ci NOT NULL,
  `theme_id` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `appeal_steps`
--

CREATE TABLE IF NOT EXISTS `appeal_steps` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `appeal_id` char(36) collate utf8_unicode_ci NOT NULL,
  `num` int(2) NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `visits` int(11) NOT NULL default '0',
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `attachments`
--

CREATE TABLE IF NOT EXISTS `attachments` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `url` varchar(500) collate utf8_unicode_ci NOT NULL,
  `mimetype` varchar(50) collate utf8_unicode_ci NOT NULL,
  `size` int(11) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_keys`
--

CREATE TABLE IF NOT EXISTS `auth_keys` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` varchar(255) collate utf8_unicode_ci NOT NULL,
  `auth_key_type_id` char(36) collate utf8_unicode_ci NOT NULL,
  `key` varchar(64) collate utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `expires` datetime default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `unique_key` (`key`),
  UNIQUE KEY `one_key_per_type` (`user_id`,`auth_key_type_id`),
  KEY `auth_key_type_id` (`auth_key_type_id`),
  KEY `user_id` (`user_id`),
  KEY `auth_key_type_id_2` (`auth_key_type_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `auth_key_types`
--

CREATE TABLE IF NOT EXISTS `auth_key_types` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(64) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bugs`
--

CREATE TABLE IF NOT EXISTS `bugs` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `increment` int(11) NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci default NULL,
  `url` varchar(60) collate utf8_unicode_ci NOT NULL,
  `last_thing` text collate utf8_unicode_ci NOT NULL,
  `bug_descr` text collate utf8_unicode_ci NOT NULL,
  `browser` varchar(30) collate utf8_unicode_ci NOT NULL,
  `created` date NOT NULL,
  `updated` date NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cards`
--

CREATE TABLE IF NOT EXISTS `cards` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `number` varchar(25) collate utf8_unicode_ci NOT NULL,
  `cardholder_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `verification_code` char(4) collate utf8_unicode_ci NOT NULL,
  `expire_month` char(2) collate utf8_unicode_ci NOT NULL,
  `expire_year` char(4) collate utf8_unicode_ci NOT NULL,
  `type` enum('mastercard','visa','visa electron','amex','diners club','JCB') collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `chats`
--

CREATE TABLE IF NOT EXISTS `chats` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `key` varchar(45) collate utf8_unicode_ci NOT NULL default '',
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `message` text collate utf8_unicode_ci NOT NULL,
  `ip_address` varchar(15) collate utf8_unicode_ci NOT NULL default '',
  `created` datetime default NULL,
  PRIMARY KEY  (`id`),
  KEY `KEY_IDX` (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cities`
--

CREATE TABLE IF NOT EXISTS `cities` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `country_id` char(36) collate utf8_unicode_ci NOT NULL,
  `state_id` char(36) collate utf8_unicode_ci default NULL,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `country_id` (`country_id`),
  KEY `state_id` (`state_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE IF NOT EXISTS `comments` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `parent_id` char(36) collate utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `increment` int(11) NOT NULL default '0',
  `body` text collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contacts`
--

CREATE TABLE IF NOT EXISTS `contacts` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `fname` varchar(255) collate utf8_unicode_ci default NULL,
  `lname` varchar(255) collate utf8_unicode_ci NOT NULL,
  `salutation` varchar(5) collate utf8_unicode_ci default NULL,
  `title` varchar(10) collate utf8_unicode_ci NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `newsletter` tinyint(1) NOT NULL,
  `contactable` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `created_by` char(36) collate utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `countries`
--

CREATE TABLE IF NOT EXISTS `countries` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `countries_offices`
--

CREATE TABLE IF NOT EXISTS `countries_offices` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  `country_id` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencies`
--

CREATE TABLE IF NOT EXISTS `currencies` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `sign` char(1) collate utf8_unicode_ci NOT NULL,
  `iso_code` char(3) collate utf8_unicode_ci NOT NULL,
  `fractional_unit_name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencies_gateways`
--

CREATE TABLE IF NOT EXISTS `currencies_gateways` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `currency_id` char(36) collate utf8_unicode_ci NOT NULL,
  `gateway_id` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `currencies_offices`
--

CREATE TABLE IF NOT EXISTS `currencies_offices` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `currency_id` char(36) collate utf8_unicode_ci NOT NULL,
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `emails`
--

CREATE TABLE IF NOT EXISTS `emails` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `contact_id` char(36) collate utf8_unicode_ci NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `contactable` tinyint(1) NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE IF NOT EXISTS `favorites` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) collate utf8_unicode_ci NOT NULL,
  `model` varchar(30) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `filters`
--

CREATE TABLE IF NOT EXISTS `filters` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `url` text collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gateways`
--

CREATE TABLE IF NOT EXISTS `gateways` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `uses_price` tinyint(1) NOT NULL default '0',
  `uses_rate` tinyint(1) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gateways_offices`
--

CREATE TABLE IF NOT EXISTS `gateways_offices` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `gateway_id` char(36) collate utf8_unicode_ci NOT NULL,
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `gifts`
--

CREATE TABLE IF NOT EXISTS `gifts` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `continuous_id` int(11) NOT NULL default '0' COMMENT 'dynamic part of the order_id (cf. friends)',
  `status` varchar(10) collate utf8_unicode_ci NOT NULL default 'new',
  `serial` varchar(20) collate utf8_unicode_ci NOT NULL,
  `due` tinyint(1) NOT NULL default '0',
  `type` varchar(20) collate utf8_unicode_ci NOT NULL default 'donation',
  `amount` float NOT NULL,
  `description` text collate utf8_unicode_ci NOT NULL,
  `frequency` varchar(20) collate utf8_unicode_ci NOT NULL,
  `currency_id` char(36) collate utf8_unicode_ci NOT NULL,
  `appeal_id` char(36) collate utf8_unicode_ci NOT NULL,
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  `contact_id` char(36) collate utf8_unicode_ci default NULL,
  `name` varchar(255) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `complete` tinyint(1) NOT NULL default '0',
  `archived` tinyint(1) NOT NULL default '0',
  `archived_time` datetime default NULL,
  `created` datetime NOT NULL,
  `created_by` char(36) collate utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `imports`
--

CREATE TABLE IF NOT EXISTS `imports` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `serial` varchar(20) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `invited_friends`
--

CREATE TABLE IF NOT EXISTS `invited_friends` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `tellfriend_id` char(36) collate utf8_unicode_ci NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `sender_email` varchar(255) collate utf8_unicode_ci default NULL,
  `registered` tinyint(1) NOT NULL,
  `time_sent` timestamp NOT NULL default CURRENT_TIMESTAMP,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE IF NOT EXISTS `logs` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `continuous_id` int(11) NOT NULL auto_increment,
  `title` varchar(200) collate utf8_unicode_ci NOT NULL,
  `model` varchar(40) collate utf8_unicode_ci NOT NULL,
  `model_id` char(36) collate utf8_unicode_ci NOT NULL,
  `action` varchar(10) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `ip` varchar(20) collate utf8_unicode_ci NOT NULL,
  `change` text collate utf8_unicode_ci NOT NULL,
  `description` varchar(500) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `continous_id` (`continuous_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Table structure for table `offices`
--

CREATE TABLE IF NOT EXISTS `offices` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(100) collate utf8_unicode_ci NOT NULL,
  `acronym` varchar(3) collate utf8_unicode_ci NOT NULL,
  `parent_id` char(36) collate utf8_unicode_ci NOT NULL,
  `country_id` char(36) collate utf8_unicode_ci NOT NULL,
  `state_id` char(36) collate utf8_unicode_ci NOT NULL,
  `city_id` char(36) collate utf8_unicode_ci NOT NULL,
  `frequencies` varchar(255) collate utf8_unicode_ci NOT NULL default 'onetime,monthly,annualy',
  `amounts` varchar(255) collate utf8_unicode_ci NOT NULL default '5,10,15',
  `currencies` varchar(500) collate utf8_unicode_ci NOT NULL default 'EUR',
  `languages` varchar(500) collate utf8_unicode_ci NOT NULL default 'eng',
  `gift_types` varchar(500) collate utf8_unicode_ci NOT NULL default 'donation',
  `live` tinyint(1) NOT NULL default '0',
  `external_url` varchar(300) collate utf8_unicode_ci default NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `phones`
--

CREATE TABLE IF NOT EXISTS `phones` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `contact_id` char(36) collate utf8_unicode_ci NOT NULL,
  `address_id` char(36) collate utf8_unicode_ci NOT NULL,
  `phone` varchar(30) collate utf8_unicode_ci NOT NULL,
  `is_fax` tinyint(1) NOT NULL default '0',
  `contactable` tinyint(1) NOT NULL default '1',
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE IF NOT EXISTS `posts` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `title` varchar(50) collate utf8_unicode_ci default NULL,
  `body` text collate utf8_unicode_ci,
  `created` datetime default NULL,
  `modified` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE IF NOT EXISTS `referrals` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `referred_id` char(36) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports`
--

CREATE TABLE IF NOT EXISTS `reports` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `title` varchar(100) collate utf8_unicode_ci NOT NULL,
  `filename` varchar(100) collate utf8_unicode_ci NOT NULL,
  `view` varchar(100) collate utf8_unicode_ci NOT NULL,
  `query` text collate utf8_unicode_ci NOT NULL,
  `frequency` enum('daily','monthly','yearly') collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `reports_users`
--

CREATE TABLE IF NOT EXISTS `reports_users` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `report_id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `last_sent` datetime default NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

CREATE TABLE IF NOT EXISTS `roles` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(15) collate utf8_unicode_ci NOT NULL,
  `permissions` varchar(900) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `office_id` char(36) collate utf8_unicode_ci default NULL COMMENT 'null == global scope',
  `created` datetime NOT NULL,
  `created_by` char(36) collate utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `segments`
--

CREATE TABLE IF NOT EXISTS `segments` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci NOT NULL,
  `segment_item_count` int(11) NOT NULL default '0',
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `segment_items`
--

CREATE TABLE IF NOT EXISTS `segment_items` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `segment_id` char(36) collate utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) collate utf8_unicode_ci NOT NULL,
  `model` varchar(100) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `session_instances`
--

CREATE TABLE IF NOT EXISTS `session_instances` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `key` varchar(32) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) collate utf8_unicode_ci default NULL,
  `data` blob,
  `expires` int(11) default NULL,
  PRIMARY KEY  (`id`),
  UNIQUE KEY `key` (`key`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `smileys`
--

CREATE TABLE IF NOT EXISTS `smileys` (
  `id` char(36) NOT NULL,
  `code` varchar(20) NOT NULL,
  `filename` varchar(20) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

CREATE TABLE IF NOT EXISTS `states` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `country_id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(200) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `country_id` (`country_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `supporters`
--

CREATE TABLE IF NOT EXISTS `supporters` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `email` varchar(255) collate utf8_unicode_ci NOT NULL,
  `password` varchar(255) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`),
  KEY `email` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tellfriends`
--

CREATE TABLE IF NOT EXISTS `tellfriends` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `user_id` char(36) character set latin1 NOT NULL,
  `receiver` text character set latin1 NOT NULL,
  `sender` varchar(255) collate utf8_unicode_ci default NULL,
  `content` text character set latin1 NOT NULL,
  `ip` varchar(255) character set latin1 NOT NULL,
  `time_sent` timestamp NOT NULL default CURRENT_TIMESTAMP,
  `sent` tinyint(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `templates`
--

CREATE TABLE IF NOT EXISTS `templates` (
  `id` char(36) character set utf8 collate utf8_unicode_ci NOT NULL,
  `published` tinyint(1) NOT NULL default '0',
  `name` varchar(255) character set utf8 collate utf8_unicode_ci NOT NULL,
  `slug` varchar(100) character set utf8 collate utf8_unicode_ci NOT NULL,
  `lang` varchar(3) character set utf8 collate utf8_unicode_ci NOT NULL,
  `template_step_count` int(2) NOT NULL,
  `processing` varchar(10) character set utf8 collate utf8_unicode_ci NOT NULL default 'direct',
  `created` datetime NOT NULL,
  `created_by` char(36) character set utf8 collate utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) character set utf8 collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `template_steps`
--

CREATE TABLE IF NOT EXISTS `template_steps` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `template_id` char(36) collate utf8_unicode_ci NOT NULL,
  `template_step_visit_count` int(11) NOT NULL default '0',
  `num` int(2) NOT NULL,
  `slug` varchar(100) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `template_step_visits`
--

CREATE TABLE IF NOT EXISTS `template_step_visits` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `template_step_id` char(36) collate utf8_unicode_ci NOT NULL,
  `foreign_id` char(36) collate utf8_unicode_ci NOT NULL,
  `pageviews` int(11) NOT NULL default '0',
  `ip` varchar(20) collate utf8_unicode_ci NOT NULL,
  `created` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE IF NOT EXISTS `themes` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `name` varchar(50) collate utf8_unicode_ci NOT NULL,
  `code` char(4) collate utf8_unicode_ci NOT NULL,
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `archived` tinyint(4) NOT NULL default '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE IF NOT EXISTS `transactions` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `parent_id` char(36) collate utf8_unicode_ci NOT NULL,
  `gateway_id` char(36) collate utf8_unicode_ci NOT NULL COMMENT 'used for gateway id aka reference',
  `external_id` char(36) collate utf8_unicode_ci default NULL COMMENT 'used for other system integration',
  `gift_id` char(36) collate utf8_unicode_ci NOT NULL,
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  `import_id` char(36) collate utf8_unicode_ci default NULL COMMENT 'id of the batch job that created the record',
  `serial` varchar(20) collate utf8_unicode_ci NOT NULL,
  `status` varchar(100) collate utf8_unicode_ci NOT NULL default 'new',
  `description` varchar(255) collate utf8_unicode_ci default NULL,
  `amount` float NOT NULL,
  `currency_id` char(36) collate utf8_unicode_ci NOT NULL COMMENT 'propagated from gift',
  `archived` tinyint(1) NOT NULL default '0',
  `archived_time` datetime default NULL,
  `created` datetime NOT NULL,
  `created_by` char(36) collate utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` char(36) collate utf8_unicode_ci NOT NULL,
  `permissions` text collate utf8_unicode_ci NOT NULL,
  `name` varchar(150) collate utf8_unicode_ci NOT NULL,
  `login` varchar(50) collate utf8_unicode_ci NOT NULL,
  `password` varchar(50) collate utf8_unicode_ci NOT NULL,
  `active` tinyint(1) NOT NULL default '0',
  `lang` varchar(5) collate utf8_unicode_ci NOT NULL default 'eng',
  `role_id` char(36) collate utf8_unicode_ci NOT NULL,
  `office_id` char(36) collate utf8_unicode_ci NOT NULL,
  `contact_id` varchar(36) collate utf8_unicode_ci NOT NULL,
  `referral_key` varchar(10) collate utf8_unicode_ci NOT NULL,
  `locale` varchar(50) collate utf8_unicode_ci NOT NULL,
  `has_donated` tinyint(1) NOT NULL default '0',
  `tooltips` tinyint(1) NOT NULL default '1',
  `public_key` text collate utf8_unicode_ci,
  `created` datetime NOT NULL,
  `created_by` char(36) collate utf8_unicode_ci NOT NULL,
  `modified` datetime NOT NULL,
  `modified_by` char(36) collate utf8_unicode_ci NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

